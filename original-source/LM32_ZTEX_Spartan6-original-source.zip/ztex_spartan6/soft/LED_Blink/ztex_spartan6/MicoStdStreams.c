/* This file defines string-constants representing stdstream devices */
/* THIS FILE IS DYNAMICALLY GENERATED AND SHOULD NOT BE MODIFIED     */
#ifdef __cplusplus
extern "C" {
#endif

const char* MICO_STDIN_DEV_NAME = "";
const char* MICO_STDOUT_DEV_NAME = "";
const char* MICO_STDERR_DEV_NAME = "";


#ifdef __cplusplus
}
#endif

